import { motion } from "framer-motion";
import { Flame, Dice5, Wallet } from "lucide-react";

export default function App() {
  const games = [
    { name: "Crash", icon: <Flame /> },
    { name: "Double", icon: <Dice5 /> },
    { name: "Slots", icon: <Wallet /> },
    { name: "Roleta", icon: <Dice5 /> },
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#000', color: '#fff', fontFamily: 'Arial' }}>
      <header style={{ display:'flex', justifyContent:'space-between', padding:16, borderBottom:'1px solid #7f1d1d' }}>
        <h1 style={{ color:'#dc2626' }}>FuriaBetBrasil</h1>
        <div>
          <button>Entrar</button>
          <button style={{ marginLeft:8, background:'#dc2626', color:'#fff' }}>Registrar</button>
        </div>
      </header>

      <section style={{ padding:24 }}>
        <motion.div initial={{opacity:0, y:20}} animate={{opacity:1, y:0}}
          style={{ background:'linear-gradient(90deg,#7f1d1d,#450a0a)', borderRadius:16, padding:24 }}>
          <h2>Bem-vindo à FuriaBetBrasil</h2>
          <p>Aposte com segurança.</p>
          <button style={{ background:'#000', color:'#fff' }}>Jogar agora</button>
        </motion.div>
      </section>

      <section style={{ padding:24 }}>
        <h3>Jogos em Destaque</h3>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(120px,1fr))', gap:16 }}>
          {games.map((g,i)=>(
            <div key={i} style={{ border:'1px solid #7f1d1d', borderRadius:12, padding:16, textAlign:'center' }}>
              <div style={{ color:'#dc2626' }}>{g.icon}</div>
              <strong>{g.name}</strong>
            </div>
          ))}
        </div>
      </section>

      <footer style={{ padding:16, borderTop:'1px solid #7f1d1d', color:'#a1a1aa' }}>
        © 2026 FuriaBetBrasil LTDA • Jogue com responsabilidade
      </footer>
    </div>
  );
}